/**
 * @author mch
 */

package constant

const RabbitmqRouterKey = "test2-consumer"
