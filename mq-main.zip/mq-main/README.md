封装 rabbitmq 和 kafka,实现消息的投递
