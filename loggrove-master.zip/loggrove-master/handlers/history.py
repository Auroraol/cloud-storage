# Created by zhouwang on 2018/6/8.

from .base import BaseRequestHandler, permission

# 处理用户历史记录查询
class Handler(BaseRequestHandler):
    @permission()
    def get(self):
        response_data = self._query()
        self._write(response_data)

    def _query(self):
        # 执行 SQL 查询语句，传递当前用户的 ID 作为参数
        self.cursor.execute(self.select_sql, self.requser['id'])
        results = self.cursor.dictfetchall()
        return dict(code=200, msg='Query Successful', data=results)
    # SQL 查询语句，用于从 auditlog 表中查询指定用户的最近100条记录
    select_sql = '''
      SELECT
        uri,
        method,
        date_format(record_time, "%%Y-%%m-%%d %%H:%%i:%%s") as record_time
      FROM
        auditlog
      WHERE 
        user_id=%s
      ORDER BY -record_time 
      LIMIT 100                 
    '''