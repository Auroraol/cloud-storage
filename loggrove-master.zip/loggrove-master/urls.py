# Created by zhouwang on 2018/5/5.

from handlers import (
    html,
    login,
    logout,
    user,
    password,
    auditlog,
    dashboard,
    profile,
    history,
    logfile,
    monitor_item,
    read,
    keepread,
    chart,
    path,
    match_regex,
    host_logfile,
    monitor_report
)



# urlpatterns = [
#     (r'/', html.Handler),
#     (r'^/dashboard/$', dashboard.Handler),
#     (r'^/login/html/$', html.LoginHander),
#     (r'^/(logfiles|read|keepread|charts|users|auditlogs)/html/$', html.Handler),
#     (r'^/login/$', login.Handler),
#     (r'^/logout/$', logout.Handler),
#     (r'^/profile/$', profile.Handler),
#     (r'^/historys/$', history.Handler),
#     (r'^/users/$', user.Handler),
#     (r'^/users/(\d+)/$', user.Handler),
#     (r'^/users/(\d+)/password/$', password.ResetHandler),
#     (r'^/password/$', password.Handler),
#     (r'^/auditlogs/$', auditlog.Handler),
#     (r'^/logfiles/$', logfile.Handler),
#     (r'^/logfiles/(\d+)/$', logfile.Handler),
#     (r'^/monitor/items/$', monitor_item.Handler),
#     (r'^/monitor/items/(\d+)/$', monitor_item.Handler),
#     (r'^/read/$', read.Handler),
#     (r'^/keepread/$', keepread.Handler),
#     (r'^/charts/$', chart.Handler),
#     (r'^/paths/$', path.Handler),
#     (r'^/match_regexs/$', match_regex.Handler),
#     (r'^/host_logfiles/$', host_logfile.Handler),
#     (r'^/monitor_report/$', monitor_report.Handler),
# ]

urlpatterns = [
    (r'/', html.Handler),  # 根路径，使用 html.Handler 处理
    (r'^/dashboard/$', dashboard.Handler),  # /dashboard 路径，使用 dashboard.Handler 处理
    (r'^/login/html/$', html.LoginHander),  # /login/html 路径，使用 html.LoginHander 处理
    (r'^/(logfiles|read|keepread|charts|users|auditlogs)/html/$', html.Handler),  # 匹配多个路径后缀为 /html 的 URL，使用 html.Handler 处理
    (r'^/login/$', login.Handler),  # /login 路径，使用 login.Handler 处理
    (r'^/logout/$', logout.Handler),  # /logout 路径，使用 logout.Handler 处理
    (r'^/profile/$', profile.Handler),  # /profile 路径，使用 profile.Handler 处理
    (r'^/historys/$', history.Handler),  # /historys 路径，使用 history.Handler 处理
    (r'^/users/$', user.Handler),  # /users 路径，使用 user.Handler 处理
    (r'^/users/(\d+)/$', user.Handler),  # /users/<数字ID> 路径，使用 user.Handler 处理，捕获用户ID
    (r'^/users/(\d+)/password/$', password.ResetHandler),  # /users/<数字ID>/password 路径，使用 password.ResetHandler 处理，捕获用户ID
    (r'^/password/$', password.Handler),  # /password 路径，使用 password.Handler 处理
    (r'^/auditlogs/$', auditlog.Handler),  # /auditlogs 路径，使用 auditlog.Handler 处理
    (r'^/logfiles/$', logfile.Handler),  # /logfiles 路径，使用 logfile.Handler 处理
    (r'^/logfiles/(\d+)/$', logfile.Handler),  # /logfiles/<数字ID> 路径，使用 logfile.Handler 处理，捕获日志文件ID
    (r'^/monitor/items/$', monitor_item.Handler),  # /monitor/items 路径，使用 monitor_item.Handler 处理
    (r'^/monitor/items/(\d+)/$', monitor_item.Handler),  # /monitor/items/<数字ID> 路径，使用 monitor_item.Handler 处理，捕获监控项ID
    (r'^/read/$', read.Handler),  # /read 路径，使用 read.Handler 处理
    (r'^/keepread/$', keepread.Handler),  # /keepread 路径，使用 keepread.Handler 处理
    (r'^/charts/$', chart.Handler),  # /charts 路径，使用 chart.Handler 处理
    (r'^/paths/$', path.Handler),  # /paths 路径，使用 path.Handler 处理
    (r'^/match_regexs/$', match_regex.Handler),  # /match_regexs 路径，使用 match_regex.Handler 处理
    (r'^/host_logfiles/$', host_logfile.Handler),  # /host_logfiles 路径，使用 host_logfile.Handler 处理
    (r'^/monitor_report/$', monitor_report.Handler),  # /monitor_report 路径，使用 monitor_report.Handler 处理
]